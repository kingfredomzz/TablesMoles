package king.echomood.periodictable.data;

/**
 * Created by king on 9/23/16.
 */

public class SampleObject {

    public  String header1;
    public  String header2;
    public  String header3;
    public  String header4;
    public  String header5;
    public  String header6;
    public  String header7;
    public  String header8;
    public  String header9;
    public  String header10;
    public  String header11;
    public  String header12;
    public  String header13;
    public  String header14;
    public  String header15;
    public  String header16;
    public  String header17;
    public  String header18;
    public  String header19;
    public  String header20;
    public  String header21;
    public  String header22;
    public  String header23;
    public  String header24;


    public SampleObject(String header1, String header2, String header3,
                        String header4, String header5, String header6,
                        String header7, String header8, String header9,String header10, String header11, String header12,
                        String header13, String header17, String header21,
                        String header14, String header18, String header22 ,
                        String header15, String header19, String header23,
                        String header16, String header20, String header24 ){

        this.header1  = header1;
        this.header2  = header2;
        this.header3  = header3;
        this.header4  = header4;
        this.header5  = header5;
        this.header6  = header6;
        this.header7  = header7;
        this.header8  = header8;
        this.header9  = header9;
        this.header10 = header10;
        this.header11 = header11;
        this.header12 = header12;
        this.header13 = header13;
        this.header14 = header14;
        this.header15 = header15;
        this.header16 = header16;
        this.header17 = header17;
        this.header18 = header18;
        this.header19 = header19;
        this.header20 = header20;
        this.header21 = header21;
        this.header22 = header22;
        this.header23 = header23;
        this.header24 = header24;


    }
}